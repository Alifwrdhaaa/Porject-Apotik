-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 28 Jun 2023 pada 06.22
-- Versi server: 10.1.38-MariaDB
-- Versi PHP: 7.3.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_apotik`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_detpembelian`
--

CREATE TABLE `tb_detpembelian` (
  `No_Beli` varchar(5) DEFAULT NULL,
  `Kode_Obat` varchar(7) DEFAULT NULL,
  `Jumlah_Beli` int(3) DEFAULT NULL,
  `Jumlah_Harga` int(8) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_detpembelian`
--

INSERT INTO `tb_detpembelian` (`No_Beli`, `Kode_Obat`, `Jumlah_Beli`, `Jumlah_Harga`) VALUES
('001', '02', 2, 24000),
('01', '02', 2, 24000),
('01', '02', 2, 24000),
('01', '02', 2, 24000),
('', '02', 2, 24000),
('', '02', 2, 24000),
('', '02', 2, 24000),
('', '02', 2, 24000),
('', '02', 2, 24000),
('01', '04', 2, 50000),
('01', '04', 2, 50000),
('01', '02', 2, 24000),
('01', '02', 2, 24000),
('01', '02', 2, 24000),
('01', '02', 2, 24000),
('01', '02', 2, 24000),
('01', '02', 1, 12000),
('01', '02', 1, 12000),
('01', '02', 1, 12000),
('002', '03', 2, 74000),
('002', '03', 2, 74000),
('002', '03', 2, 74000),
('002', '03', 2, 74000),
('01', '04', 2, 50000),
('01', '04', 2, 50000),
('002', '03', 2, 74000),
('01', '06', 2, 40000),
('01', '06', 2, 40000),
('01', '06', 2, 40000),
('01', '06', 2, 40000),
('02', '07', 2, 70000),
('02', '07', 2, 70000),
('02', '07', 2, 70000),
('01', '07', 2, 70000),
('01', '07', 2, 70000),
('03', '06', 2, 40000),
('03', '02', 2, 24000),
('001', '03', 2, 74000),
('08', '06', 2, 40000),
('023', '02', 2, 24000),
('023', '03', 2, 74000),
('023', '03', 2, 74000),
('023', '02', 2, 24000),
('023', '02', 2, 24000),
('023', '03', 1, 37000),
('02', '07', 2, 70000),
('02', '07', 2, 70000),
('09', '04', 2, 50000),
('3', '02', 3, 36000),
('', '4444', -5, 5000),
('', '4444', -5, 5000),
('', '4444', -5, 5000),
('', '4444', -5, 5000),
('', '4444', -5, 5000),
('', '4444', -5, 5000),
('', '4444', -5, 5000),
('', '4444', -5, 5000),
('', '4444', -5, 5000),
('', '4444', -5, 5000),
('', '4444', -5, 5000),
('', '4444', -5, 5000),
('', '4444', -5, 5000),
('', '4444', -5, 5000),
('', '4444', -5, 5000),
('', '4444', -5, 5000),
('', '4444', -5, 5000),
('', '4444', -5, 5000),
('', '4444', -5, 5000),
('', '4444', -5, 5000),
('', '4444', -5, 5000),
('', '4444', -5, 5000),
('', '4444', -5, 5000),
('', '4444', -5, 5000),
('', '05', -5, 5000),
('', '4444', -5, 5000),
('', '4444', -5, 5000),
('', '4444', -5, 5000),
('', '4444', -5, 5000),
('', '4444', -5, 5000),
('', '4444', -5, 5000),
('', '4444', -5, 5000),
('', '4444', -5, 5000),
('', '4444', -5, 5000),
('', '4444', -5, 5000),
('', '4444', -5, 5000),
('', '4444', -5, 5000),
('', '4444', -5, 5000),
('', '4444', -5, 5000),
('', '4444', -5, 5000),
('', '4444', -5, 5000),
('', '4444', -5, 5000),
('', '4444', -5, 5000),
('', '4444', -5, 5000),
('', '4444', -5, 5000),
('', '4444', -5, 5000),
('', '4444', -5, 5000),
('', '4444', -5, 5000),
('', '4444', -5, 5000),
('', '05', -5, 5000),
('', '4444', -5, 5000),
('', '4444', -5, 5000),
('', '4444', -5, 5000),
('', '4444', -5, 5000),
('', '4444', -5, 5000),
('', '4444', -5, 5000),
('', '4444', -5, 5000),
('', '4444', -5, 5000),
('', '4444', -5, 5000),
('', '4444', -5, 5000),
('', '4444', -5, 5000),
('', '4444', -5, 5000),
('', '4444', -5, 5000),
('', '4444', -5, 5000),
('', '4444', -5, 5000),
('', '4444', -5, 5000),
('', '4444', -5, 5000),
('', '4444', -5, 5000),
('', '4444', -5, 5000),
('', '4444', -5, 5000),
('', '4444', -5, 5000),
('', '4444', -5, 5000),
('', '4444', -5, 5000),
('', '4444', -5, 5000),
('', '05', -5, 5000),
('hhh', '4444', -5, 5000),
('hhh', '4444', -5, 5000),
('hhh', '4444', -5, 5000),
('hhh', '4444', -5, 5000),
('hhh', '4444', -5, 5000),
('hhh', '4444', -5, 5000),
('hhh', '4444', -5, 5000),
('hhh', '4444', -5, 5000),
('hhh', '4444', -5, 5000),
('hhh', '4444', -5, 5000),
('hhh', '4444', -5, 5000),
('hhh', '4444', -5, 5000),
('hhh', '4444', -5, 5000),
('hhh', '4444', -5, 5000),
('hhh', '4444', -5, 5000),
('hhh', '4444', -5, 5000),
('hhh', '4444', -5, 5000),
('hhh', '4444', -5, 5000),
('hhh', '4444', -5, 5000),
('hhh', '4444', -5, 5000),
('hhh', '4444', -5, 5000),
('hhh', '4444', -5, 5000),
('hhh', '4444', -5, 5000),
('hhh', '4444', -5, 5000),
('hhh', '05', -5, 5000);

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_detpenjualan`
--

CREATE TABLE `tb_detpenjualan` (
  `No_Jual` varchar(5) DEFAULT NULL,
  `Kode_Obat` varchar(7) DEFAULT NULL,
  `Jumlah_Jual` int(3) DEFAULT NULL,
  `Jumlah_Harga` int(8) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_detpenjualan`
--

INSERT INTO `tb_detpenjualan` (`No_Jual`, `Kode_Obat`, `Jumlah_Jual`, `Jumlah_Harga`) VALUES
('02', '03', 2, 74000),
('01', '06', 2, 40000),
('08', '07', 2, 70000),
('01', '02', 2, 24000),
('02', '04', 2, 50000),
('02', '02', 1, 12000),
('2', '07', 2, 70000),
('3', '03', 2, 74000);

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_karyawan`
--

CREATE TABLE `tb_karyawan` (
  `Id_Karyawan` varchar(30) NOT NULL,
  `Nama_Karyawan` varchar(25) DEFAULT NULL,
  `Password` varchar(10) DEFAULT NULL,
  `Jabatan` varchar(40) DEFAULT NULL,
  `JK` varchar(10) DEFAULT NULL,
  `Alamat` varchar(35) DEFAULT NULL,
  `No_Hp` varchar(12) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_karyawan`
--

INSERT INTO `tb_karyawan` (`Id_Karyawan`, `Nama_Karyawan`, `Password`, `Jabatan`, `JK`, `Alamat`, `No_Hp`) VALUES
('002', 'jaiwr', '123456', 'direktur', 'L', 'jln mahali', '0997867575'),
('003', 'Nicko', '12345678', 'menejer', 'L', 'the hall', '0987654456'),
('004', 'Akbar', '12345678', 'karyawan', 'L', 'tebet', '0987677876'),
('005', 'jawir', 'user', 'karyawan', 'P', 'jln margonda', '0987654468'),
('', '', '', 'menejer', 'P', '', ''),
('001', 'bujang', '1234567', 'directur', 'L', 'jln kuy', '12345678');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_konsumen`
--

CREATE TABLE `tb_konsumen` (
  `Id_Konsumen` varchar(5) NOT NULL,
  `Nama_Konsumen` varchar(25) DEFAULT NULL,
  `Alamat_Konsumen` varchar(35) DEFAULT NULL,
  `No_Hp` varchar(12) DEFAULT NULL,
  `JK` varchar(12) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_konsumen`
--

INSERT INTO `tb_konsumen` (`Id_Konsumen`, `Nama_Konsumen`, `Alamat_Konsumen`, `No_Hp`, `JK`) VALUES
('P-002', 'jamal', 'jln trilogi', '098765432123', 'Laki-Laki'),
('P-003', 'gilang', 'the hall', '0988675463', 'Transgender'),
('P-004', 'immanuel', 'jl haji naim', '098765646363', 'Laki-Laki'),
('P-005', 'Anik', 'kalibata', '090978689597', 'Perempuan'),
('P-006', 'Rifqi', 'setia budi', '099789695', 'Transgender'),
('ufdyr', '', '', '', 'Transgender');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_login`
--

CREATE TABLE `tb_login` (
  `Username` varchar(50) NOT NULL,
  `Password` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_login`
--

INSERT INTO `tb_login` (`Username`, `Password`) VALUES
('admin', 'admin');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_obat`
--

CREATE TABLE `tb_obat` (
  `Kode_Obat` varchar(8) NOT NULL,
  `Nama_Obat` varchar(12) DEFAULT NULL,
  `Jenis_Obat` varchar(6) DEFAULT NULL,
  `Harga` int(6) DEFAULT NULL,
  `Tanggal_Expired` date DEFAULT NULL,
  `Stok` int(3) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_obat`
--

INSERT INTO `tb_obat` (`Kode_Obat`, `Nama_Obat`, `Jenis_Obat`, `Harga`, `Tanggal_Expired`, `Stok`) VALUES
('01', 'antimo', 'Tablet', 0, '2023-06-07', 1),
('02', 'sanmol', 'Pil', 12000, '2023-06-08', 2),
('03', 'activet', 'Pil', 37000, '2023-06-09', 3),
('04', 'neoralgin', 'Tables', 25000, '2023-06-09', 4),
('05', 'madol', 'Pil', 0, '2023-06-11', 4),
('06', 'tramadol', 'Pil', 20000, '2023-06-20', 4),
('07', 'konidine', 'Sirup', 35000, '2023-06-20', 6),
('', '', 'Pil', 0, '2023-06-26', 2),
('4444', '4444', 'Pil', -1000, '2023-06-01', -100);

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_pembelian`
--

CREATE TABLE `tb_pembelian` (
  `No_Pembelian` varchar(5) NOT NULL,
  `Tgl_Beli` date DEFAULT NULL,
  `Id_Supplier` varchar(7) DEFAULT NULL,
  `Id_Karyawan` varchar(5) DEFAULT NULL,
  `Jumlah_Item` int(3) DEFAULT NULL,
  `Total_Item` int(8) DEFAULT NULL,
  `Total_Bayar` int(8) DEFAULT NULL,
  `Kembalian` int(8) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_pembelian`
--

INSERT INTO `tb_pembelian` (`No_Pembelian`, `Tgl_Beli`, `Id_Supplier`, `Id_Karyawan`, `Jumlah_Item`, `Total_Item`, `Total_Bayar`, `Kembalian`) VALUES
('', '2023-06-26', '001', '005', -130, 130000, -300000, -430000),
('09', '2023-06-20', '002', '003', 2, 50000, 100000, 50000);

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_penjualan`
--

CREATE TABLE `tb_penjualan` (
  `No_Penjualan` varchar(5) NOT NULL,
  `Tgl_Jual` date DEFAULT NULL,
  `Id_Konsumen` varchar(5) DEFAULT NULL,
  `Id_Karyawan` varchar(5) DEFAULT NULL,
  `Jumlah_Item` int(3) DEFAULT NULL,
  `Total_Harga` int(8) DEFAULT NULL,
  `Total_Biaya` int(8) DEFAULT NULL,
  `Kembalian` int(8) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_penjualan`
--

INSERT INTO `tb_penjualan` (`No_Penjualan`, `Tgl_Jual`, `Id_Konsumen`, `Id_Karyawan`, `Jumlah_Item`, `Total_Harga`, `Total_Biaya`, `Kembalian`) VALUES
('02', '2023-06-20', 'P-002', '004', 1, 12000, 15000, 3000),
('2', '2023-06-25', 'P-002', '004', 2, 70000, 80000, 10000),
('3', '2023-06-26', 'P-004', '005', 2, 74000, 80000, 6000);

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_supplier`
--

CREATE TABLE `tb_supplier` (
  `Id_Supplier` varchar(7) NOT NULL,
  `Nm_Supplier` varchar(35) DEFAULT NULL,
  `Alamat` varchar(35) DEFAULT NULL,
  `No_Hp` varchar(12) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_supplier`
--

INSERT INTO `tb_supplier` (`Id_Supplier`, `Nm_Supplier`, `Alamat`, `No_Hp`) VALUES
('001', 'ali', 'surga', '12345345'),
('002', 'tors', 'trilogi', '67575494974');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `tb_karyawan`
--
ALTER TABLE `tb_karyawan`
  ADD PRIMARY KEY (`Id_Karyawan`);

--
-- Indeks untuk tabel `tb_konsumen`
--
ALTER TABLE `tb_konsumen`
  ADD PRIMARY KEY (`Id_Konsumen`);

--
-- Indeks untuk tabel `tb_login`
--
ALTER TABLE `tb_login`
  ADD PRIMARY KEY (`Username`);

--
-- Indeks untuk tabel `tb_obat`
--
ALTER TABLE `tb_obat`
  ADD PRIMARY KEY (`Kode_Obat`);

--
-- Indeks untuk tabel `tb_pembelian`
--
ALTER TABLE `tb_pembelian`
  ADD PRIMARY KEY (`No_Pembelian`);

--
-- Indeks untuk tabel `tb_penjualan`
--
ALTER TABLE `tb_penjualan`
  ADD PRIMARY KEY (`No_Penjualan`);

--
-- Indeks untuk tabel `tb_supplier`
--
ALTER TABLE `tb_supplier`
  ADD PRIMARY KEY (`Id_Supplier`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
